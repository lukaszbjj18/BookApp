package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast

class DictionaryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dictionary)

        var listView = findViewById<ListView>(R.id.DictionaryList)
        listView.setOnItemClickListener { parent, view, position, id ->
            Toast.makeText(this@DictionaryActivity,"Klika sobie", Toast.LENGTH_LONG) }

    }
}
